/**
 * Orchestration class for Account
 */
public class AccountDemo
{
    public static void main(String [] args)  {
        Account maryAccount, johnAccount;

        johnAccount = new Account(1000, 1000, 100);
        System.out.print("John's ");
        johnAccount.showData();
        System.out.println(Account.numOfAccounts+" accounts opened");

        maryAccount = new Account(2000, 2000, 200);   
        System.out.print("Mary's ");
        maryAccount.showData();
        System.out.println(Account.numOfAccounts+" accounts opened");

        maryAccount = johnAccount; //assigning maryAccount to johnAccount
        System.out.print("John's ");
        johnAccount.showData();
        System.out.print("Mary's ");
        maryAccount.showData();
        
        System.out.println(Account.numOfAccounts+" accounts opened");

    }

}
